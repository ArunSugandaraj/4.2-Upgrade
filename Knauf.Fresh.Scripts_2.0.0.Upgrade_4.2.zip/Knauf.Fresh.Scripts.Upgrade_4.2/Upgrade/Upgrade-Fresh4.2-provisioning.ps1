# Files may be blocked if sent via the internet, this ensures that we unblock them
# Will fail if PowerShell was not opened as Administrator
Get-ChildItem '..' -Recurse | Unblock-File

# Add variables and functions
. ..\Environment.ps1
. ..\Utilities\UpgradeUtilitiesAzure.ps1

# ONLY IF PROVISIONING MODULE IS DEPLOYED

#-------------------------------------------
# 1. Deploy changes in provisioning engine
############################################
Write-Host "1. Deploying provisioning libraries to Azure" -ForegroundColor "yellow"

$source = "$PSScriptRoot\4.2\bin"
$destination = "site/wwwroot/bin"
Add-FilesToProvisioningAzure -Source $source -Destination $destination -CreateFolder

#-------------------------------------------
# 2. Deploy changes in content types
############################################
Write-Host "1. Deploying updated templates of content types to Azure" -ForegroundColor "yellow"

$source = "$PSScriptRoot\4.2\CC.Community.PnP"
$destination = "site/wwwroot/ProvisioningTemplates/CC.Community.PnP"
Add-FilesToProvisioningAzure -Source $source -Destination $destination -CreateFolder

$source = "$PSScriptRoot\4.2\CC.ContentSite.PnP"
$destination = "site/wwwroot/ProvisioningTemplates/CC.ContentSite.PnP"
Add-FilesToProvisioningAzure -Source $source -Destination $destination -CreateFolder

$source = "$PSScriptRoot\4.2\CC.FreshCommon.PnP"
$destination = "site/wwwroot/ProvisioningTemplates/CC.FreshCommon.PnP"
Add-FilesToProvisioningAzure -Source $source -Destination $destination -CreateFolder

# Knauf custom templates
$source = "$PSScriptRoot\4.2\CC.Company.PnP"
$destination = "site/wwwroot/ProvisioningTemplates/CC.Company.PnP"
Add-FilesToProvisioningAzure -Source $source -Destination $destination -CreateFolder

$source = "$PSScriptRoot\4.2\CC.Division.PnP"
$destination = "site/wwwroot/ProvisioningTemplates/CC.Division.PnP"
Add-FilesToProvisioningAzure -Source $source -Destination $destination -CreateFolder

$source = "$PSScriptRoot\4.2\CC.Function.PnP"
$destination = "site/wwwroot/ProvisioningTemplates/CC.Function.PnP"
Add-FilesToProvisioningAzure -Source $source -Destination $destination -CreateFolder

$source = "$PSScriptRoot\4.2\CC.Location.PnP"
$destination = "site/wwwroot/ProvisioningTemplates/CC.Location.PnP"
Add-FilesToProvisioningAzure -Source $source -Destination $destination -CreateFolder

$source = "$PSScriptRoot\4.2\CC.Process.PnP"
$destination = "site/wwwroot/ProvisioningTemplates/CC.Process.PnP"
Add-FilesToProvisioningAzure -Source $source -Destination $destination -CreateFolder

$source = "$PSScriptRoot\4.2\CC.ProductGroup.PnP"
$destination = "site/wwwroot/ProvisioningTemplates/CC.ProductGroup.PnP"
Add-FilesToProvisioningAzure -Source $source -Destination $destination -CreateFolder

$source = "$PSScriptRoot\4.2\CC.Region.PnP"
$destination = "site/wwwroot/ProvisioningTemplates/CC.Region.PnP"
Add-FilesToProvisioningAzure -Source $source -Destination $destination -CreateFolder