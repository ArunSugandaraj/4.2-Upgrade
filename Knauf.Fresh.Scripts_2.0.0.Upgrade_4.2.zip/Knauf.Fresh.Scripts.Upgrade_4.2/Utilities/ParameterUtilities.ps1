﻿$genericHubFolderPath = "$PSScriptRoot\..\Deploy-GenericHub\Files"
$provisioningTemplatesFolderPath = "$PSScriptRoot\..\ProvisioningTemplates"
$solutionsFolderPath = "$PSScriptRoot\..\SolutionPackages"


Function Get-DeploymentParameters(
  $Instance, 
  $EntityType, 
  $SiteTitle, 
  $SiteName, 
  $SiteTypeStamp, 
  $IncludeGlobalNavigation = $true,
  $ReplaceModernHeader = $true, 
  $EntitiesToCreateFilePath = $null,
  $SettingsTaxonomyFilePath = "$genericHubFolderPath\settings-taxonomy.xml",
  $SearchFilePath = "$genericHubFolderPath\search.xml",
  $SiteTemplateFilePath = "$genericHubFolderPath\hub.pnp.xml"
) {
  $settingsTokens = $Instance.FreshTaxParameters
  $settingsTokens.EntityName = $EntityType.Name
  $settingsTokens.EntityTermId = $EntityType.Guid
  $settingsTokens.EntityContentTypeId = $EntityType.ContentTypeId
  $settingsTokens.SettingsGroupName = $Instance.GlobalSettings.GroupName
  $settingsTokens.SettingsGroupGuid = $Instance.GlobalSettings.GroupGuid

  $deploymentParameters = @{
    InstanceTaxonomy = @(
      @{
        FilePath                    = $SettingsTaxonomyFilePath
        UsesSiteCollectionTermStore = $false
        Tokens                      = $settingsTokens
      }
    )
    Search           = @(
      @{
        FilePath    = $SearchFilePath
        TenantScope = $true # Tenant or SiteCollection scope
      }
    )
  }

  if ($EntityType.ShouldCreateTerm) {
    $deploymentParameters.InstanceTaxonomy += @{
      FilePath                    = "$genericHubFolderPath\taxonomy.xml"
      UsesSiteCollectionTermStore = $false
      Tokens                      = @{
        GroupGuid         = Get-Value $Instance $EntityType.Term.GroupGuidInstanceProp
        GroupName         = Get-Value $Instance $EntityType.Term.GroupNameInstanceProp
        EntityTermSetGuid = Get-Value $Instance $EntityType.Term.TermSetGuidInstanceProp
        EntityTermSetName = Get-Value $Instance $EntityType.Term.TermSetNameInstanceProp
      }
    }
  }

  if ($null -ne $SiteTitle -and $null -ne $SiteName) { 
    $deploymentParameters.SiteCollectionInfos = @(Get-HubInfo $Instance $EntityType $SiteTitle $SiteName $SiteTypeStamp $SiteTemplateFilePath $ReplaceModernHeader)
  }

  if ($null -ne $EntitiesToCreateFilePath) {
    $deploymentParameters.ChildEntities = @{
      Instance                 = $Instance
      Entity                   = $EntityType
      EntitiesToCreateFilePath = $EntitiesToCreateFilePath
    }
  }

  return $deploymentParameters
}



Function Get-HubInfo($Instance, $EntityType, $SiteTitle, $SiteName, $SiteTypeStamp, $SiteTemplateFilePath, $ReplaceModernHeader = $true) {
  $completeSiteTitle = "$($Instance.TitlePrefix) $SiteTitle".Trim()
  $tenantRelativeUrl = "/sites/$($Instance.InstancePrefix)$SiteName"

  $globalNavigationCustomAction = @{
    Title                 = 'GlobalNavigationApplicationCustomizer'
    Location              = 'ClientSideExtension.ApplicationCustomizer'
    ClientSideComponentId = '63be6d0b-999c-45a2-ad79-ab068457f32f'
    ComponentProperties   = "{""replaceModernHeader"": $($ReplaceModernHeader.toString().toLower()), ""topNavigationTermSetId"": ""$($Instance.TopNavigationTermSetGuid)"", ""footerNavigationTermSetId"": ""$($Instance.FooterNavigationTermSetGuid)""}"
  }

  $contentTypeTemplatePath = "$provisioningTemplatesFolderPath\CC.$($EntityType.Name.Replace(' ', '')).PnP\$($EntityType.Name.Replace(' ', '').ToLower())-contenttype.xml"

  $hubInfo = @{
    SiteTitle      = $completeSiteTitle
    SiteUrl        = "$global:tenantUrl$tenantRelativeUrl"
    Template       = $CONSTANTS.Enums.SiteTemplates.ModernCommunicationSite
    SiteLogo       = @{ 
      FileName         = "siteIcon-fresh.png"
      SourceFolderPath = "$provisioningTemplatesFolderPath\CC.FreshCommon.PnP\Resources"
      TargetLibrayName = "SiteAssets"
    }
    IsHubSite      = $null -ne $EntityType.Site.HubSiteName
    TimeZoneId     = $Instance.DefaultTimeZoneId
    LocaleId       = $Instance.DefaultLocaleId
    FirstDayOfWeek = $Instance.DefaultFirstDayOfWeek
    AppPackages    = @(
      @{
        FilePath = "$solutionsFolderPath\candc-fresh-contentwebparts.sppkg"
      }
      @{
        FilePath = "$solutionsFolderPath\candc-fresh-governanceadmin.sppkg"
      }
      @{
        FilePath = "$solutionsFolderPath\candc-fresh-intranetwebparts.sppkg"
      }
      @{
        FilePath = "$solutionsFolderPath\candc-fresh-usercentricwebparts.sppkg"
      }
      @{
        FilePath = "$solutionsFolderPath\candc-fresh-coredwp.sppkg"
      }
    )
    Provisioning   = @(
      @{
        FilePath   = "$provisioningTemplatesFolderPath\CC.FreshCommon.PnP\sitecolumns.pnp.xml"
        Parameters = $Instance.FreshTaxParameters
      }
      @{
        FilePath = "$provisioningTemplatesFolderPath\CC.FreshCommon.PnP\sitecontenttypes.pnp.xml"
      }
      @{
        FilePath = "$provisioningTemplatesFolderPath\CC.FreshCommon.PnP\sitelibraries.pnp.xml"
      }
      @{
        FilePath = $contentTypeTemplatePath
      }
      @{
        FilePath   = $SiteTemplateFilePath
        Parameters = @{
          SiteTypeStamp = $SiteTypeStamp
          InstanceStamp = $Instance.InstanceStamp
          BannerProps   = Get-BannerProps $SiteTitle
          RollupProps   = Get-RollupProps $Instance $EntityType
        }
      }
    )
    Theme          = @{
      FilePath = $Instance.ThemeFilePath
    }
  }

  if ($IncludeGlobalNavigation) {
    $hubInfo.CustomActions = @(
      $globalNavigationCustomAction
    )
  }

  if ($Instance.SearchResultSiteName) {
    $hubInfo.SearchResultPageUrl = "$global:tenantUrl/sites/$($Instance.InstancePrefix)$($Instance.SearchResultSiteName)/sitepages/search-results.aspx"
  }

  return $hubInfo
}



Function Get-BannerProps($Title) {
  return @"
  {
    "title": "$Title",
    "hideTools": true,
    "alertType": 1,
    "sectionLogoType": 1,
    "sectionLogoIcon": "Globe",
    "sectionContent": 2,
    "sectionContentScope": 1,
    "isFullWidth": true
  }
"@
}



Function Get-RollupProps($Instance, $EntityType) {
  $scope = "4"
  $scopeQuery = "Path:$global:tenantUrl/sites/$($Instance.InstancePrefix)*"
  if ($EntityType.Type -eq $CONSTANTS.Enums.EntityStructures.Page) {
    $scope = "3"
    $scopeQuery = "Path:{\\Site}"
  }
  return @"
  {
    "entities": [
      {
        "id": "$($EntityType.Guid)",
        "label": "$($EntityType.Name)",
        "contentTypeId": "$($EntityType.ContentTypeId)"
      }
    ],
    "displayMode": 1,
    "displayModeStyle": 1,
    "textPosition": 3,
    "clampDescription": true,
    "useRoundedCorners": true,
    "itemsPerPage": 12,
    "density": 4,
    "autoplayCarouselTimeout": 3,
    "thumbnailType": 1,
    "linkText": "See more",
    "backgroundType": 2,
    "showDescription": true,
    "showActions": true,
    "showDetails": true,
    "showSiteLogo": true,
    "showFollowedOnly": false,
    "showFollowedOnTop": false,
    "defaultIcon": "SharepointLogo",
    "linkTarget": 2,
    "requestButtonText": "Request",
    "backgroundColor": "#2e2442",
    "iconBackgroundColor": "#9e00b7",
    "isPaged": true,
    "showSearchbox": true,
    "query": {
      "scope": $scope,
      "queryTemplate": "{searchTerms} $scopeQuery",
      "rowsPerPage": 20,
      "rowLimit": 20,
      "trimDuplicates": false,
      "selectProperties": [],
      "sortList": [
        {
          "managedProperty": "ViewsRecent",
          "ascending": false
        }
      ],
      "isDialogOpen": false,
      "hubSiteId": null,
      "path": "$global:tenantUrl/sites/$($Instance.InstancePrefix)*"
    }
  }
"@
}


Function Get-Value ($Hash, $PropPath) {
  $val = $Hash
  $PropPath.Split(".") | ForEach-Object { $val = $val[$_] }
  return $val
}