#Import-Module AzureRM.Resources

# Import utility functions
. ..\Utilities\DeployUtilities.ps1


Function Login-Azure($parameters) {
  LogWaiting "Login to Azure"
  if ($global:useWebLogin -eq $false) {
    $credentials = Import-Clixml -Path $global:storedCredentialsPath
    $subscriptions = az login -u $credentials.UserName -p $credentials.GetNetworkCredential().Password #--only-show-errors
  }
  else {
    $subscriptions = az login #--only-show-errors
  }
  $subscription = az account set --subscription $global:subscriptionId #--only-show-errors
  LogSuccess "done"
  
}

Function Login-AzurePowershell($parameters) {
  LogWaiting "Login to Azure"
  if ($global:useWebLogin -eq $false) {
    $credentials = Import-Clixml -Path $global:storedCredentialsPath
    Connect-AzAccount -Credential $credentials -Subscription $global:subscriptionId
  }
  else {
    Connect-AzAccount -Subscription $global:subscriptionId
  }
  LogSuccess "done"
}

Function Create-AzureADAppRegistration($parameters) {
  LogWaiting "Creating AAD app registration..."
  $requiredApp = az ad app create --display-name $parameters.AzureConfig.AadAppDisplayName `
    --required-resource-accesses $parameters.AzureConfig.AadAppManifestFilePath | ConvertFrom-Json
  LogSuccess "Done."

  
  LogWaiting "Updating settings of the app registration..."
  if ($parameters.AzureConfig.AadAppAllowImplicitFlow) {
    az ad app update --id $requiredApp.appId --set oauth2AllowImplicitFlow=true
  }
  if($parameters.AzureConfig.AadAppSetIdentifierUris){
    $functionUrl = "https://$($parameters.AzureConfig.FunctionAppName).azurewebsites.net"
    az ad app update --id $requiredApp.appId --identifier-uris @($functionUrl) --reply-urls @($functionUrl) --homepage $functionUrl
  }
  az ad app permission admin-consent --id $requiredApp.appId
  LogSuccess "Done."
  
}

Function Create-SSLCertificate($parameters) {
  LogWaiting "Creating certificate"
  . ..\Utilities\Create-SelfSignedCertificate.ps1 -CommonName $parameters.AzureConfig.Certificate.Name -StartDate $parameters.AzureConfig.Certificate.StartDate -EndDate $parameters.AzureConfig.Certificate.EndDate -Password (ConvertTo-SecureString -String $parameters.AzureConfig.Certificate.Password -AsPlainText -Force) -CerPath $parameters.AzureConfig.Certificate.CerPath -PfxPath $parameters.AzureConfig.Certificate.PfxPath #-Force
  LogSuccess "Done"
}

Function Add-SSLCertToAppRegistration($parameters) {
  $appClientId = Get-AzureADAppClientId $parameters
  $base64Cert = Get-Base64Cert $parameters
  az ad app update --id $appClientId --key-type "AsymmetricX509Cert" --key-usage "Verify" --key-value $base64Cert
}


Function Create-AzureResourceGroup($parameters) {
  if ($null -ne $parameters.AzureConfig.ResourceGroupName) {
    LogWaiting "Creating Azure Resource Group..."
    az group create --name $parameters.AzureConfig.ResourceGroupName --location $parameters.AzureConfig.ResourceGroupLocation
    LogSuccess "Done"
  }
  else {
    LogInfo("Skipped")
  }
}

Function Apply-AzureTemplates($parameters) {
  if ($null -ne $parameters.AzureConfig.Templates) {
    $parameters.AzureConfig.Templates | ForEach-Object {
      $template = $_
      $templateParameters = $template.Parameters
      if ($template.DynamicParameters) {
        $template.DynamicParameters | ForEach-Object {
          if ($_.Function) {
            $result = & $_.Function $parameters
            $templateParameters += @{ Key = $_.Key; Value = $result }
          }
        }
      }
      $parametersArray = @()
      $templateParameters | ForEach-Object { $parametersArray += $_.Key + "=" + $_.Value }

      LogWaiting "Applying Azure template..."
      az deployment group create --resource-group $parameters.AzureConfig.ResourceGroupName `
        --template-file $template.FilePath `
        --parameters $parametersArray

      LogSuccess "Done"
    }
  }
  else {
    LogInfo("Skipped")
  }
}

Function Create-Queue($parameters) {
  if ($null -ne $parameters.AzureConfig.QueueName) {
    LogWaiting "Creating queue"
    $storageConnectionString = az storage account show-connection-string -g $parameters.AzureConfig.ResourceGroupName -n $parameters.AzureConfig.StorageAccountName --output tsv
    az storage queue create --name $parameters.AzureConfig.QueueName --connection-string $storageConnectionString
    LogSuccess "Done"
  }
  else {
    LogInfo("Skipped")
  }
}

Function Copy-TemplatesToFunctionFolder($parameters) {
  LogWaiting "Creating link to templates"
  New-Item -ItemType SymbolicLink -Path "$PSScriptRoot\..\Deploy-Provisioning\Files\wwwroot\ProvisioningTemplates" -Value "$PSScriptRoot\..\ProvisioningTemplates" -Force
  LogSuccess "Done"
}

Function Create-Zip($parameters) {
  if ($null -ne $parameters.AzureConfig.ZipFilePath) {
    LogWaiting "Creating zip"
    Compress-Archive -Path $parameters.AzureConfig.AzureFunctionCodePath -DestinationPath $parameters.AzureConfig.ZipFilePath -Force
    LogSuccess "Done"
  }
  else {
    LogInfo("Skipped")
  }
}

Function Publish-CodeToAzureFunction($parameters) {
  if ($null -ne $parameters.AzureConfig.ZipFilePath -and $null -ne $parameters.AzureConfig.FunctionAppName) {
    LogWaiting "Publishing Azure Function code to Function App"
    az functionapp deployment source config-zip -g $parameters.AzureConfig.ResourceGroupName -n $parameters.AzureConfig.FunctionAppName --src $parameters.AzureConfig.ZipFilePath
    LogSuccess "Done"
  }
  else {
    LogInfo("Skipped")
  }
}

Function Get-AzureADAppClientId($parameters) {
  if ($null -ne $parameters.AzureConfig.AadAppDisplayName) {
    $apps = az ad app list --display-name $parameters.AzureConfig.AadAppDisplayName | ConvertFrom-Json;
    $requiredApp = $apps[0]
    return $requiredApp.appId
  }
}

Function Get-Base64Cert($parameters) {
  $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($parameters.AzureConfig.Certificate.CerPath, $parameters.AzureConfig.Certificate.Password, 0)
  #$cert.Import($parameters.AzureConfig.Certificate.CerPath, $parameters.AzureConfig.Certificate.Password, 0)
  $rawCert = $cert.GetRawCertData()
  return [System.Convert]::ToBase64String($rawCert)
}

Function Get-PfxBase64($parameters) {
  $pfxFileBytes = get-content $parameters.AzureConfig.Certificate.PfxPath -Encoding Byte
  return [System.Convert]::ToBase64String($pfxFileBytes)
}

Function Get-CertificateThumbprint($parameters) {
  $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2
  $cert.Import($parameters.AzureConfig.Certificate.CerPath)
  return $cert.Thumbprint
}


Function Get-InstrumentationKey($groupName, $appInsightsName) {
  $k = az resource show -g $groupName -n $appInsightsName --resource-type "Microsoft.Insights/components" --query properties.InstrumentationKey
  return $k.trim('"')
}

Function Get-StorageAccountKey($groupName, $accountName) {
  $k = az storage account keys list --resource-group $groupName --account-name $accountName --query "[0].value"
  return $k.trim('"')
}

Function Create-WebAnalyticsPageViewTable($parameters) {
  if ($null -ne $parameters.AzureConfig.CreateTableSqlFilePath) {
    if (-not (Get-Module -ListAvailable -Name "SqlServer")) {
      Install-Module -Name "SqlServer" -Scope CurrentUser -AllowClobber -Confirm:$false
    }
    Invoke-SqlCmd `
      -ServerInstance "$($parameters.AzureConfig.Sqlserver.Name).database.windows.net" `
      -Database $parameters.AzureConfig.Sqlserver.DataBaseName `
      -Username $parameters.AzureConfig.Sqlserver.AdminLogin `
      -Password $parameters.AzureConfig.Sqlserver.AdminPassword `
      -InputFile $parameters.AzureConfig.CreateTableSqlFilePath
  }
  else {
    LogInfo("Skipped")
  }
}

Function Create-WebAnalyticsContinuousExport($parameters) {
  if ($null -ne $parameters.AzureConfig.ContiniusExportStorageAccountName) {
    if (-not (Get-Module -ListAvailable -Name "Az.Storage")) {
      Install-Module -Name "Az.Storage" -Scope CurrentUser -AllowClobber -Confirm:$false
    }
    $storageAccountKey = Get-StorageAccountKey $parameters.AzureConfig.ResourceGroupName $parameters.AzureConfig.ContiniusExportStorageAccountName
    $context = New-AzStorageContext -StorageAccountName $parameters.AzureConfig.ContiniusExportStorageAccountName -StorageAccountKey $storageAccountKey # -UseConnectedAccount
    $sastoken = New-AzStorageContainerSASToken `
      -Name $parameters.AzureConfig.ContiniusExportStorageAccountContaninerName `
      -Context $context `
      -ExpiryTime (Get-Date).AddDays(5) `
      -Permission w
    $sasuri = "https://$($parameters.AzureConfig.ContiniusExportStorageAccountName).blob.core.windows.net/$($parameters.AzureConfig.ContiniusExportStorageAccountContaninerName)" + $sastoken
    New-AzApplicationInsightsContinuousExport `
      -ResourceGroupName $parameters.AzureConfig.ResourceGroupName `
      -Name $parameters.AzureConfig.AppInsightsName `
      -DocumentType "Page View" `
      -StorageAccountId "/subscriptions/$global:subscriptionId/resourceGroups/$($parameters.AzureConfig.ResourceGroupName)/providers/Microsoft.Storage/storageAccounts/$($parameters.AzureConfig.ContiniusExportStorageAccountName)" `
      -StorageLocation $parameters.AzureConfig.ResourceGroupLocation `
      -StorageSASUri $sasuri
  }
  else {
    LogInfo("Skipped")
  }
}

Function Start-WebAnalyticsStreamingJob($parameters) {
  if ($null -ne $parameters.AzureConfig.StreamingjobName) {
    Start-AzStreamAnalyticsJob -ResourceGroupName $parameters.AzureConfig.ResourceGroupName -Name $parameters.AzureConfig.StreamingjobName -OutputStartMode LastOutputEventTime
  }
  else {
    LogInfo("Skipped")
  }
}


# STEP DEFINITIONS
$DeployStepsAzure = @{
    
  LoginToAzure                       = @{
    Name     = "Login to Azure"
    Function = Get-Item function:Login-Azure
  }
  LoginToAzurePowershell             = @{
    Name     = "Login to Azure"
    Function = Get-Item function:Login-AzurePowershell
  }
  CreateAzureADAppRegistration       = @{
    Name     = "Create an App Registration in Azure Active Directory"
    Function = Get-Item function:Create-AzureADAppRegistration
  }
  CreateAzureResourceGroup           = @{
    Name     = "Create Azure Resource group"
    Function = Get-Item function:Create-AzureResourceGroup
  }
  ApplyAzureTemplates                = @{
    Name     = "Apply Azure templates"
    Function = Get-Item function:Apply-AzureTemplates
  }
  CreateQueue                        = @{
    Name     = "Create Azure Storage entities - queue"
    Function = Get-Item function:Create-Queue
  }
  CreateSSLCertificate               = @{
    Name     = "Create Self Signed Certificate"
    Function = Get-Item function:Create-SSLCertificate 
  }
  AddSSLCertToAppRegistration        = @{
    Name     = "Add Certificate to AAD App registration"
    Function = Get-Item function:Add-SSLCertToAppRegistration
  }
  CopyTemplatesToFunctionFolder      = @{
    Name     = "Copy the templates to the function folder"
    Function = Get-Item function:Copy-TemplatesToFunctionFolder
  }
  CreateZip                          = @{
    Name     = "Create ZIP with the files to upload"
    Function = Get-Item function:Create-Zip
  }
  PublishCodeToAzureFunction         = @{
    Name     = "Publishing Azure Function code to Function App"
    Function = Get-Item function:Publish-CodeToAzureFunction
  }
  CreateWebAnalyticsContinuousExport = @{
    Name     = "Creating continuous export"
    Function = Get-Item function:Create-WebAnalyticsContinuousExport
  }
  StartWebAnalyticsStreamingJob      = @{
    Name     = "Start streaming job"
    Function = Get-Item function:Start-WebAnalyticsStreamingJob
  }
  CreateWebAnalyticsPageViewTable    = @{
    Name     = "Creating Page View table in the database"
    Function = Get-Item function:Create-WebAnalyticsPageViewTable
  }
}