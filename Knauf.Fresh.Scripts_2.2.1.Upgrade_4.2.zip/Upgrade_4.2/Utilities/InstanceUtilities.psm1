Function Merge-Instances {
  param(
    $Instances, 
    $Tenant
  )

  # add tenant keys to the default instance
  $Tenant.Keys | ForEach-Object {
    $Instances.Default[$_] = $Tenant[$_]
  }

  # every instance, except the Default instance, overwrite properties to the Default instance
  $Instances.Keys | Where-Object { $_ -ne "Default" } | ForEach-Object {
    $instanceKey = $_
    # Merge properties
    $Instances.Default.Keys | ForEach-Object {
      if (-not $Instances[$instanceKey].ContainsKey($_)) {
        $Instances[$instanceKey][$_] = $Instances.Default[$_]
      }
    }
    # 2nd level properties
    if ($Instances.Default.NavigationParameters) {
      $Instances.Default.NavigationParameters.Keys | ForEach-Object { 
        if (-not $Instances[$instanceKey].NavigationParameters.ContainsKey($_)) {
          $Instances[$instanceKey].NavigationParameters[$_] = $Instances.Default.NavigationParameters[$_] 
        }
      }
    }
    if ($Instances.Default.FreshTaxParameters) {
      $Instances.Default.FreshTaxParameters.Keys | ForEach-Object { 
        if (-not $Instances[$instanceKey].FreshTaxParameters.ContainsKey($_)) {
          $Instances[$instanceKey].FreshTaxParameters[$_] = $Instances.Default.FreshTaxParameters[$_]
        }
      }
    }
  }
  
  return $Instances
}

Export-ModuleMember -Function Merge-Instances