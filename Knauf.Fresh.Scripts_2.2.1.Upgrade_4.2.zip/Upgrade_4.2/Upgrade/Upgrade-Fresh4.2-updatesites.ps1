# Files may be blocked if sent via the internet, this ensures that we unblock them
# Will fail if PowerShell was not opened as Administrator
Get-ChildItem '..' -Recurse | Unblock-File

# Add variables and functions
. ..\Environment.ps1
. ..\Utilities\DeployUtilities.ps1
Import-Module ..\Utilities\DeployConstants -Force
Import-Module ..\Files\Instances -Force
$instances = Get-Instances

try {
  Start-Transcript -path $CONSTANTS.PathToLogFile -ErrorAction SilentlyContinue
}
catch [System.Exception] {
  LogWarning "Unable to start transcription of this session" -f Red
}


$instancesToUpgrade = $instances.Values #all the instances
$sites = @()

Authenticate-PnpPowerShell $global:tenantAdminUrl
$instancesToUpgrade | Foreach-Object {
  if ($null -ne $_.InstancePrefix -and "" -ne $_.InstancePrefix) {
    Get-PnPTenantSite -Filter "Url -like '/sites/$($_.InstancePrefix)'" | ForEach-Object { $sites += $_.Url }
  }
  else {
    $results = Submit-PnPSearchQuery -Query "FreshInstance=$($_.InstanceStamp)" -SelectProperties "Path"
    $results.ResultRows | ForEach-Object { $sites += $_.Path }
  }
}


Write-Host "The apps will be updated in the following Fresh sites ($($sites.Length)):" -ForegroundColor Yellow
$sites | Foreach-Object { Write-Host "   $_" }
$left = New-TimeSpan -Seconds ($sites.Length * 40)
LogWarning "The process will take around$(if($left.Hours -gt 0) {" $($left.Hours) hours"}) $($left.Minutes) minutes$(if($left.Seconds -gt 0) {" and $($left.Seconds) seconds"})."
Read-Host "Press Enter to continue"


function UpdateSite($SiteUrl, $WorkingDirectory) {
  try {
    Set-Location $WorkingDirectory
    Import-Module ..\Utilities\DeployConstants -Force
    . ..\Environment.ps1
    . ..\Utilities\DeploySteps

    Authenticate-PnpPowerShell $SiteUrl

    $appPackages = @(
      @{ app = $CONSTANTS.AppPackages.ContentWebparts; action = "UPDATE" }
      @{ app = $CONSTANTS.AppPackages.UsercentricWebparts; action = "UPDATE" }
      @{ app = $CONSTANTS.AppPackages.DigitalWorkplaceWebparts; action = "UPDATE_OR_INSTALL" }
      @{ app = $CONSTANTS.AppPackages.IntranetWebparts; action = "UPDATE" }
      @{ app = $CONSTANTS.AppPackages.DashboardsACEs; action = "UPDATE" }
      @{ app = $CONSTANTS.AppPackages.ToolAdminWebparts; action = "UPDATE" }
      @{ app = $CONSTANTS.AppPackages.AnalyticWebparts; action = "UPDATE" }
      @{ app = $CONSTANTS.AppPackages.ProvisioningWebparts; action = "UPDATE" }
      @{ app = $CONSTANTS.AppPackages.ChecklistWebparts; action = "UPDATE" }
      @{ app = $CONSTANTS.AppPackages.GovernanceWebparts; action = "UPDATE_OR_INSTALL" }
      @{ app = $CONSTANTS.AppPackages.WebsiteWebparts; action = "UPDATE_OR_INSTALL"; check = $true }
      @{ app = $CONSTANTS.AppPackages.MediaWebparts; action = "UPDATE_OR_INSTALL"; check = $true }
    )

    ##Install the app
    $apps = Get-PnPApp
    $appPackages | ForEach-Object {
      $appDefinition = $_
      $appInfo = Get-PnPAppInfo -ProductId $appDefinition.app.ProductId
      $app = $apps | Where-Object { $_.Title -eq $appInfo.Name }
      if ($app -and $app.Id) {
        if ($app.InstalledVersion) {
          if ($app.InstalledVersion.Major -ne 4 -or $app.InstalledVersion.Minor -ne 2) {
            LogWaiting "Updating $($app.Title) app"
            Update-PnPApp -Identity $app.Id
            LogSuccess "done"
          }
          else {
            LogWarning "The $($app.Title) app is already upgraded"
          }
        }
        else {
          if ($appDefinition.action -eq "UPDATE_OR_INSTALL") {
            LogWaiting "Installing $($app.Title) app"
            Install-PnPApp -Identity $app.Id
            LogSuccess "done"
          }
          else {
            LogInfo "Skip $($app.Title) app installation"
          }
        }
      }
      else {
        LogError "$($appDefinition.app.FilePath) app not found in the app catalog"      
      }
    }

    ##Create revision columns
    if (-not (Get-PnPField -Identity "CandC_ReviewDate" -ErrorAction Ignore)) {
      LogWaiting "Adding column 'Review date' to the site"
      $xml = '<Field ID="{f0b78a7d-5887-4c20-9df0-678d1e4309a3}" Type="DateTime" Name="CandC_ReviewDate" StaticName="CandC_ReviewDate" DisplayName="Review date" Description="Date for revision" Format="DateOnly" Required="FALSE" Group="Fresh Columns" />'
      $f = Add-PnPFieldFromXml -FieldXml $xml
      Add-PnPFieldToContentType -Field "CandC_ReviewDate" -ContentType "Fresh document"
      Add-PnPField -Field "CandC_ReviewDate" -List "SitePages"
      Get-PnPContentType -List "SitePages" | ForEach-Object {
        if ($_.Name -ne "Folder" -and $_.Name -ne "Repost Page" -and $_.Name -ne "Site Page" ) {
          Add-PnPFieldToContentType -Field "CandC_ReviewDate" -ContentType $_.Name
        }
      }
      LogSuccess "done"
    }
    else {
      LogWarning "The column 'Review date' already exists"
    }
    
    if (-not (Get-PnPField -Identity "CandC_ContentOwner" -ErrorAction Ignore)) {
      LogWaiting "Adding column 'Content owner' to the site"
      $xml = '<Field ID="{a0eb6a43-aed9-4c3f-a01d-6afa3dc2a7e6}" Type="User" StaticName="CandC_ContentOwner" Name="CandC_ContentOwner" DisplayName="Content owner" Required="FALSE" Group="Fresh Columns" List="UserInfo" EnforceUniqueValues="FALSE" ShowField="ImnName" UserSelectionMode="PeopleOnly" UserSelectionScope="0" />'
      $f = Add-PnPFieldFromXml -FieldXml $xml
      Add-PnPFieldToContentType -Field "CandC_ContentOwner" -ContentType "Fresh document"
      Add-PnPField -Field "CandC_ContentOwner" -List "SitePages"
      Get-PnPContentType -List "SitePages" | ForEach-Object {
        if ($_.Name -ne "Folder" -and $_.Name -ne "Repost Page" -and $_.Name -ne "Site Page" -and $_.Name -ne "Space" ) {
          Add-PnPFieldToContentType -Field "CandC_ContentOwner" -ContentType $_.Name
        }
      }
      LogSuccess "done"
    }
    else {
      LogWarning "The column 'Content owner' already exists"
    }

    ##reindex the site
    try {
      $context = Get-PnPContext
      $web = $context.Web
      $context.Load($web)
      $siteProperties = $web.AllProperties
      $context.Load($siteProperties)
      $context.ExecuteQuery()
      LogInfo "Reindexing $($web.Title)"
      $description = $web.Description
      $web.Description = $description + " "
      $web.Update()
      $context.ExecuteQuery()
      $web.Description = $description
      $web.Update()
      $context.ExecuteQuery()
    }
    catch {

    }

    ##Double check that the apps have been installed
    $apps = Get-PnPApp
    $appPackages | Where-Object { $_.check -eq $true } | ForEach-Object {
      $appDefinition = $_
      $appInfo = Get-PnPAppInfo -ProductId $appDefinition.app.ProductId
      $app = $apps | Where-Object { $_.Title -eq $appInfo.Name }
      if (-not $app.InstalledVersion) {
        LogWarning "Reinstalling the $($app.Title) app"
        Start-Sleep -Seconds 10
        Uninstall-PnPApp -Identity $app.Id
        Start-Sleep -Seconds 12
        try {
          LogWaiting "Installing $($app.Title) app"
          Install-PnPApp -Identity $app.Id -ErrorAction Stop
          LogSuccess "done"
        }
        catch {
          Start-Sleep -Seconds 10
          LogWaiting "Installing $($app.Title) app (retry)"
          Install-PnPApp -Identity $app.Id
          LogSuccess "done"

        }
      }
    }

  }
  catch {
    Write-Host $_.Exception
  }
}


$i = 0
$startDate = (Get-Date)
$sites | Foreach-Object {
  $i++
  $tempDate = (Get-Date)
  Start-Job -ScriptBlock ${Function:UpdateSite} -ArgumentList @($_, $PSScriptRoot) | Wait-Job | Receive-Job
  LogDuration $tempDate
  $left = New-TimeSpan -Seconds (($sites.Length - $i) * 40)
  LogSuccess "$i sites of $($sites.Length) processed. The process will be finish in about$(if($left.Hours -gt 0) {" $($left.Hours) hours"}) $($left.Minutes) minutes$(if($left.Seconds -gt 0) {" and $($left.Seconds) seconds"})."
}
LogDuration $startDate

Stop-Transcript -ErrorAction SilentlyContinue

