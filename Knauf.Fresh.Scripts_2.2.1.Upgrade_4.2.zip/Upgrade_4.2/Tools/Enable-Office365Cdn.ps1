# Add variables and functions
. ..\Environment.ps1
. ..\Utilities\DeploySteps.ps1

$cdnPublicChanged = $false
$cdnPrivateChanged = $false

Authenticate-PnPPowerShell $global:tenantAdminUrl
#Enable CDN
$cdnType = 'public'
if (-not (Get-PnPTenantCdnEnabled -CdnType $cdnType).Value) {
  LogWaiting "Enabling $cdnType CDN"
  Set-PnPTenantCdnEnabled -CdnType $cdnType -Enable $true
  $cdnPublicChanged = $true
  LogSuccess "done"
}

$cdnType = 'private'
if (-not (Get-PnPTenantCdnEnabled -CdnType $cdnType).Value) {
  LogWaiting "Enabling $cdnType CDN"
  Set-PnPTenantCdnEnabled -CdnType $cdnType -Enable $true
  $cdnPrivateChanged = $true
  LogSuccess "done"
}

if (-not ($cdnPublicChanged) -and -not ($cdnPrivateChanged)) {
  Write-Host "Public and Private CDN were already enabled" -ForegroundColor "yellow"
}